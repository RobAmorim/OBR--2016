/*
 * Libray ControlMotors v1.1
 * -------------------------
 * $Based on Adafruit's library: AFMotor $
 * $Author Alberto Daniel $
 * $Date 2015-06-27 12:49:06 (Sat, 27 Jun 2015) $
 * -------------------------------------------------
 * $Encoders added in 2015-08-02 12:17:39 (Sun, 02 Aug 2015)$
 */

 //ATTACH1 = Blue Wire
 //ATTACH2 = Yellow Wire

#include <ControlMotorsEncoder.h>
#include "AFMotor.h"
#include "Encoder.h"

//MOTORS INSTANCE
AF_DCMotor mEsq(3);
AF_DCMotor mDir(2);

//ENCODERS INSTANCE
Encoder Encoder_ESQ(ATTACH1_ESQ, ATTACH2_ESQ);
Encoder Encoder_DIR(ATTACH1_DIR, ATTACH2_DIR);

Motors::Motors(){

	#define PARAR 4
	#define FRENTE 1
	#define PRA_TRAS 2
}

void Motors::maxVelocidade(){
	mEsq.setSpeed(255);
	mDir.setSpeed(255);
}

void Motors::velocidade(uint8_t speedEsq, uint8_t speedDir){
	mEsq.setSpeed(speedEsq);
	mDir.setSpeed(speedDir);
}


void Motors::frente(){
	mEsq.run(FRENTE);
	mDir.run(FRENTE);
}

void Motors::frente(int ms){
	mEsq.run(FRENTE);
	mDir.run(FRENTE);
	delay(ms);
}

void Motors::frente(uint8_t speedEsq, uint8_t speedDir){
	mEsq.setSpeed(speedEsq);
	mDir.setSpeed(speedDir);
	mEsq.run(FRENTE);
	mDir.run(FRENTE);
}

void Motors::frente(uint8_t speedEsq, uint8_t speedDir, int ms){
	mEsq.setSpeed(speedEsq);
	mDir.setSpeed(speedDir);
	mEsq.run(FRENTE);
	mDir.run(FRENTE);
	delay(ms);
}

void Motors::re(){
	mEsq.run(PRA_TRAS);
	mDir.run(PRA_TRAS);
}

void Motors::re(int ms){
	mEsq.run(PRA_TRAS);
	mDir.run(PRA_TRAS);
	delay(ms);
}

void Motors::re(uint8_t speedEsq, uint8_t speedDir){
	mEsq.setSpeed(speedEsq);
	mDir.setSpeed(speedDir);
	mEsq.run(PRA_TRAS);
	mDir.run(PRA_TRAS);
}

void Motors::re(uint8_t speedEsq, uint8_t speedDir, int ms){
	mEsq.setSpeed(speedEsq);
	mDir.setSpeed(speedDir);
	mEsq.run(PRA_TRAS);
	mDir.run(PRA_TRAS);
	delay(ms);
}

void Motors::direita(){
	mEsq.run(FRENTE);
	mDir.run(PRA_TRAS);
}

void Motors::direita(int ms){
	mEsq.run(FRENTE);
	mDir.run(PRA_TRAS);
	delay(ms);
}

void Motors::direita(uint8_t speedEsq, uint8_t speedDir){
	mEsq.setSpeed(speedEsq);
	mDir.setSpeed(speedDir);
	mEsq.run(FRENTE);
	mDir.run(PRA_TRAS);
}

void Motors::direita(uint8_t speedEsq, uint8_t speedDir, int ms){
	mEsq.setSpeed(speedEsq);
	mDir.setSpeed(speedDir);
	mEsq.run(FRENTE);
	mDir.run(PRA_TRAS);
	delay(ms);
}

void Motors::esquerda(){
	mEsq.run(PRA_TRAS);
	mDir.run(FRENTE);
}

void Motors::esquerda(int ms){
	mEsq.run(PRA_TRAS);
	mDir.run(FRENTE);
	delay(ms);
}

void Motors::esquerda(uint8_t speedEsq, uint8_t speedDir){
	mEsq.setSpeed(speedEsq);
	mDir.setSpeed(speedDir);
	mEsq.run(PRA_TRAS);
	mDir.run(FRENTE);
}

void Motors::esquerda(uint8_t speedEsq, uint8_t speedDir, int ms){
	mEsq.setSpeed(speedEsq);
	mDir.setSpeed(speedDir);
	mEsq.run(PRA_TRAS);
	mDir.run(FRENTE);
	delay(ms);
}

void Motors::parar(){
	mEsq.run(PARAR);
	mDir.run(PARAR);
}

void Motors::parar(int ms){
	mEsq.run(PARAR);
	mDir.run(PARAR);
	delay(ms);
}

void Motors::pararMicroseconds(int ms){
	mEsq.run(PARAR);
	mDir.run(PARAR);
	delay(ms);
}

//ENCODER FUNCTIONS
void Motors::frenteEncoder(int pulses){
	resetEncoders();
	readBegin();
	do {
		frente();
		readEnd();
		DeltaEncoders();
	} while(Delta_DIR < pulses && Delta_ESQ < pulses);
	resetEncoders();
}

void Motors::frenteEncoder(int pulses, uint8_t speedEsq, uint8_t speedDir){
	resetEncoders();
	readBegin();
	do {
		frente(speedEsq, speedDir);
		readEnd();
		DeltaEncoders();
	} while(Delta_DIR < pulses && Delta_ESQ < pulses);
	resetEncoders();
}

void Motors::direitaEncoder(int pulses){
	resetEncoders();
	readBegin();
	do {
		direita();
		readEnd();
		DeltaEncoders();
	} while(Delta_DIR < pulses && Delta_ESQ < pulses);
	resetEncoders();
}

void Motors::direitaEncoder(int pulses, uint8_t speedEsq, uint8_t speedDir){
	resetEncoders();
	readBegin();
	do {
		direita(speedEsq, speedDir);
		readEnd();
		DeltaEncoders();
	} while(Delta_DIR < pulses && Delta_ESQ < pulses);
	resetEncoders();
}

void Motors::esquerdaEncoder(int pulses){
	resetEncoders();
	readBegin();
	do {
		esquerda();
		readEnd();
		DeltaEncoders();
	} while(Delta_DIR < pulses && Delta_ESQ < pulses);
	resetEncoders();
}

void Motors::esquerdaEncoder(int pulses, uint8_t speedEsq, uint8_t speedDir){
	resetEncoders();
	readBegin();
	do {
		esquerda(speedEsq, speedDir);
		readEnd();
		DeltaEncoders();
	} while(Delta_DIR < pulses && Delta_ESQ < pulses);
	resetEncoders();
}
void Motors::reEncoder(int pulses){
	resetEncoders();
	readBegin();
	do {
		re();
		readEnd();
		DeltaEncoders();
	} while(Delta_DIR < pulses && Delta_ESQ < pulses);
	resetEncoders();
}

void Motors::reEncoder(int pulses, uint8_t speedEsq, uint8_t speedDir){
	resetEncoders();
	readBegin();
	do {
		re(speedEsq, speedDir);
		readEnd();
		DeltaEncoders();
	} while(Delta_DIR < pulses && Delta_ESQ < pulses);
	resetEncoders();
}

void Motors::resetEncoders(){
	Encoder_ESQ.write(0);
	Encoder_DIR.write(0);
}

//PRIVATE METHODS
void Motors::readBegin(){
	ENC_ESQ_Begin = Encoder_ESQ.read();
	ENC_DIR_Begin = Encoder_DIR.read();
}

void Motors::readEnd(){
	ENC_ESQ_End = Encoder_ESQ.read();
	ENC_DIR_End = Encoder_DIR.read();
}

void Motors::DeltaEncoders(){
	Delta_DIR = abs(ENC_DIR_End - ENC_DIR_Begin);
    Delta_ESQ = abs(ENC_ESQ_End - ENC_ESQ_Begin);
}