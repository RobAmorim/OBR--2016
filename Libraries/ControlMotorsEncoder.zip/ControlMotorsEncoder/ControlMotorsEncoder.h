/*
 * Libray ControlMotors v1.0
 * -------------------------
 * $Based on Adafruit's library: AFMotor $
 * $Author Alberto Daniel $
 * $Date 2015-06-27 12:49:06 (Sat, 27 Jun 2015) $
 */

#ifndef CONTROLMOTORS_H
#define CONTROLMOTORS_H

#include <Arduino.h>
#include "AFMotor.h"
#include "Encoder.h"

//ENCODER - SETTINGS
#define ATTACH1_ESQ 43
#define ATTACH2_ESQ 42

#define ATTACH1_DIR 41
#define ATTACH2_DIR 40

class Motors
{
public:
	Motors();
	//~Motors();

	void velocidade(uint8_t speedEsq, uint8_t speedDir);
	void maxVelocidade();

	void frente();
	void frente(int ms);
	void frente(uint8_t speedEsq, uint8_t speedDir);
	void frente(uint8_t speedEsq, uint8_t speedDir, int ms);

	void re();
	void re(int ms);
	void re(uint8_t speedEsq, uint8_t speedDir);
	void re(uint8_t speedEsq, uint8_t speedDir, int ms);

	void direita();
	void direita(int ms);
	void direita(uint8_t speedEsq, uint8_t speedDir);
	void direita(uint8_t speedEsq, uint8_t speedDir, int ms);

	void esquerda();
	void esquerda(int ms);
	void esquerda(uint8_t speedEsq, uint8_t speedDir);
	void esquerda(uint8_t speedEsq, uint8_t speedDir, int ms);

	void parar();
	void parar(int ms);
	void pararMicroseconds(int ms);

	//With Encoder
	void frenteEncoder(int pulses);
	void frenteEncoder(int pulses, uint8_t speedEsq, uint8_t speedDir);

	void direitaEncoder(int pulses);
	void direitaEncoder(int pulses, uint8_t speedEsq, uint8_t speedDir);

	void esquerdaEncoder(int pulses);
	void esquerdaEncoder(int pulses, uint8_t speedEsq, uint8_t speedDir);

	void reEncoder(int pulses);
	void reEncoder(int pulses, uint8_t speedEsq, uint8_t speedDir);

	void resetEncoders();
private:
	long Delta_DIR;
	long Delta_ESQ;
	long ENC_ESQ_Begin;
	long ENC_ESQ_End;
	long ENC_DIR_Begin;
	long ENC_DIR_End;

	void readBegin();
	void readEnd();
	void DeltaEncoders();
};
#endif

